<form action="test.php" method="post">
    <input type="text" name="str" required>
    <input type="text" name="str2" required>
    <button type="submit">Отправить</button>
</form>

<?php

$str = $_POST['str'];
$str2 = $_POST['str2'];

function string($str, $str2){
    $countStr2 = mb_strlen($str2);
    $test = substr($str, -$countStr2);
    if ($test == $str2){
        echo "true";
    }
    else{
        echo "false";
    }
}

string($str, $str2);
?>

